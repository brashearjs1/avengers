from sqlalchemy import MetaData, Table, Column, Integer, select
from sqlalchemy.engine import ResultProxy
from sqlalchemy.orm import registry
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
import mysql.connector

Base = declarative_base()
engine = create_engine('mysql+pymysql://root:dennisiscool@localhost' +
                       '/avengers', echo=False)
meta = MetaData()
meta.reflect(bind=engine, views=True)
mapper_registry = registry()


class ModelHelper:
    def __str__(self) -> str:
        d = dict(self.__dict__)
        del d['_sa_instance_state']
        s = ''
        for k in d:
            s += '{}:{}\n'.format(k, d[k])
        return s + "\n"



    @classmethod
    def resultproxy2list(cls, rows:ResultProxy):
        models = []
        for row in rows:
            d = dict(row)
            model = cls(**d)
            models.append(model)
        return models

    @classmethod
    def get_fields(cls):
        fields = cls.__table__.c.keys()
        return fields

    @classmethod
    def get_required_fields(cls):
        column_names = []
        for col in cls.__table__.columns:
            if not col.nullable:
                column_names.append(col.name)
        return column_names

    @classmethod
    def get_primary_key(cls) -> list:
        pks = cls.__table__.primary_key.columns.values()
        pk_names = []
        for pk in pks:
            if pk.primary_key:
                pk_names.append(pk.name)
        return pk_names

    def __repr__(self) -> str:
        return self.__str__()

    def to_dict(self) -> dict:
        d = dict(self.__dict__)
        del d['_sa_instance_state']
        return d

    @classmethod
    def get_table_registry(cls):
        r = mapper_registry.__dict__['_class_registry']

        del r['_sa_module_registry']
        return r


class Character(ModelHelper):
    pass


class Film(ModelHelper):
    pass

class User(ModelHelper):
    pass




mapper_registry.map_imperatively(Character, meta.tables['characters'])
mapper_registry.map_imperatively(Film, meta.tables['films'])
mapper_registry.map_imperatively(User, meta.tables['users'])


'''
r = Customer.get_table_registry()
for k in r:
    print('{} : {}'.format(k,r[k]))
'''