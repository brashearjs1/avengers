from __future__ import annotations
from tkinter import font as tkfont  # python 3
from sqlalchemy.orm import Session
from avengerslib import *
from tkinter import *
from tkinter import ttk
import tkinter as tk
import mysql.connector

class SampleApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold", slant="italic")

        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, PageOne, PageTwo, LoginPage):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            # put all of the pages in the same location;
            # the one on the top of the stacking order
            # will be the one that is visible.
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("StartPage")

    def show_frame(self, page_name):
        '''Show a frame for the given page name'''
        frame = self.frames[page_name]

        frame.tkraise()



class StartPage(tk.Frame):

    def __init__(self, parent, controller, font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue', cnf={}, **kw):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Avengers Assemble!", font=controller.title_font,bg='White')
        label.pack(side="top", fill="x", pady=10)
        self.config(bg='White')
        button1 = tk.Button(self, text="View Avengers",
                            command=lambda: controller.show_frame("PageOne"))

        button1.pack()



class PageOne(tk.Frame):

    def __init__(self, parent, controller, master=None, class_ref=None,
                 session: Session = None, font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue', cnf={}, **kw):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.session = session
        self.Table = class_ref
        self.session = session
        self.table_dict = {}
        self.config(bg=bg)
        self.config(bg='White')


        self.inner_frame = Frame(self)
        self.inner_frame.pack()
        self.inner_frame.config(bg=bg)
        session = Session(engine)
        label = tk.Label(self, text="Guest Page", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        SelectAllChar = Button(self, text='Select All Characters',
                               command=lambda: createframe(TableSelectAllFrame, Character, session))
        SelectAllFilm = Button(self, text='Select All Films',
                               command=lambda: createframe(TableSelectAllFrame, Film, session))
        SelectByChar = Button(self, text='Select Character by PK',
                              command=lambda: createframe(TableSelectByPkFrame, Character, session))
        SelectByFilm = Button(self, text='Select Film by PK',
                              command=lambda: createframe(TableSelectByPkFrame, Film, session))
        Admin = Button(self, text='Admin', command=lambda: [clear_frame(),controller.show_frame("LoginPage")])

        SelectAllChar.pack()
        SelectAllFilm.pack()
        SelectByChar.pack()
        SelectByFilm.pack()

        Admin.pack()


class LoginPage(tk.Frame):

    def __init__(self, parent, controller):
        global command
        tk.Frame.__init__(self, parent)


        self.controller = controller
        label = tk.Label(self, text="Login to Admin", font=controller.title_font)
        label.grid(row=0, column=2)
        user_label = Label(self, text="Enter valid Username")
        password_label = Label(self, text="Enter password")
        self.config(bg='White')
        username = Entry(self)
        password = StringVar()
        password = Entry(self, textvariable=password)

        button = tk.Button(self, text="Login",
                           command=lambda: [self.check(username,password),controller.show_frame(new_frame)])
        guest_button = Button(self,text='Go back to guest page',command=lambda: controller.show_frame("PageOne"))

        user_label.grid(row=2, column=1)
        username.grid(row=2, column=2)
        password_label.grid(row=3, column=1)
        password.grid(row=3, column=2)
        button.grid(row=5, column=2)
        guest_button.grid(row=6,column=2)
        self.message_label = Label(self, text='')
        self.message_label.grid(row=7,column=2)

    def check(self,username,password):
        global new_frame
        global x
        db = mysql.connector.connect(host ="localhost",
                                     user = 'root',
                                     password='dennisiscool',
                                     db ="avengers")
        cursor = db.cursor()


        h = """Select username, password from USERS """


        cursor.execute(h)



        data = []

        for row in cursor:
            for field in row:
                data.append(field)

        print(data)



        for i in range(0,len(data)):

            if username.get() == data[i] and password.get() == data[i+1]:
                new_frame = "PageTwo"

                break


            else:
                self.message_label.config(text='Wrong username or password')


class PageTwo(tk.Frame):

    def __init__(self ,parent,controller, master=None, class_ref=None,
                 session: Session = None, font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue', cnf={}, **kw):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.session = session
        self.Table = class_ref
        self.session = session
        self.table_dict = {}
        self.config(bg=bg)
        self.config(bg='White')
        self.inner_frame = Frame(self)
        self.inner_frame.pack()
        self.inner_frame.config(bg=bg)
        session = Session(engine)
        label = tk.Label(self, text="Admin Page", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        SelectAllChar = Button(self, text='Select All Characters',
                               command=lambda: createframe(TableSelectAllFrame, Character, session))
        SelectAllFilm = Button(self, text='Select All Films',
                               command=lambda: createframe(TableSelectAllFrame, Film, session))
        SelectByChar = Button(self, text='Update Character by PK',
                              command=lambda: createframe(TableSelectUpdateFrame, Character, session))
        SelectByFilm = Button(self, text='Update Film by PK',
                              command=lambda: createframe(TableSelectUpdateFrame, Film, session))
        InsertChar = Button(self, text='Insert Character',
                            command=lambda: createframe(TableInsertFrame, Character, session))
        InsertFilm = Button(self, text='Insert Film', command=lambda: createframe(TableInsertFrame, Film, session))
        Guest = Button(self, text='Go back to Guest', command=lambda: [clear_frame(),controller.show_frame("PageOne")])
        Add_user = Button(self,text='Add another Admin',command=lambda: createframe(TableInsertFrame,User,session))
        SelectAllChar.pack()
        SelectAllFilm.pack()
        SelectByChar.pack()
        SelectByFilm.pack()
        InsertChar.pack()
        InsertFilm.pack()
        Add_user.pack()
        Guest.pack()


class TableInsertFrame(Frame):

    def __init__(self, master=None, class_ref=None,
                 session: Session = None,
                 font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue',
                 cnf={}, **kw):
        super().__init__(master, cnf, **kw)
        self.Table = class_ref
        self.session = session
        self.table_dict = {}
        self.config(bg=bg)
        table_name = str(self.Table)
        table_name = table_name[table_name.rindex('.') + 1:table_name.rindex("'")]
        Label(self, text='Insert {}'.format(table_name), fg=fg, bg=bg, font=font).pack()
        self.inner_frame = Frame(self)
        self.inner_frame.pack()
        self.inner_frame.config(bg=bg)
        # fields = globals()[self.Table].get_fields()
        fields = self.Table.get_fields()
        for i in range(0, len(fields)):
            field = fields[i]
            label = Label(self.inner_frame, text=field, justify=LEFT,
                          font=font, bg=bg, fg=fg)
            label.grid(row=i, column=0, padx=5, pady=5, sticky='w')
            self.table_dict[field] = StringVar()
            entry = Entry(self.inner_frame,
                          textvar=self.table_dict[field],
                          font=font, bg=bg, fg=fg)
            entry.grid(row=i, column=1, padx=5)
            if field in self.Table.get_required_fields():
                label = Label(self.inner_frame, text='*  ',
                              font=font, bg=bg, fg=fg)
                label.grid(row=i, column=2, padx=5)
        self.insert_button = Button(self, text='Insert',
                                    command=self.insert_object,
                                    font=font, bg=bg, fg=fg)
        self.clear_button = Button(self, text='Clear',
                                   command=self.clear_fields,
                                   font=font, bg=bg, fg=fg)
        self.insert_button.pack(fill=BOTH, expand=True, padx=5)
        self.clear_button.pack(fill=BOTH, expand=True, padx=5)
        self.message_label = Label(self, text='', font=font, bg=bg, fg=fg)
        self.message_label.pack()

    def clear_fields(self):
        for k in self.table_dict:
            self.table_dict[k].set('')
        self.message_label.config(text='')

    def insert_object(self):
        obj = {}
        for k in self.table_dict.keys():
            val = self.table_dict[k].get()
            if val == '':
                obj[k] = None
            else:
                obj[k] = val
        try:
            new_object = self.Table(**obj)
            self.session.add(new_object)
            self.session.commit()
            self.message_label.config(text='Insert Successful')
        except Exception as ex:
            print(ex)
            self.message_label.config(text='Insert failed, Enter all required fields')
            session.rollback()


class TableSelectAllFrame(Frame):

    def __init__(self, master=None, class_ref=None,
                 session: Session = None,
                 font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue', cnf={}, **kw):
        super().__init__(master, cnf, **kw)
        self.table = class_ref

        self.session = session
        headings = tuple(self.table.get_fields())
        self.tree = ttk.Treeview(self, columns=headings, show='headings')
        for h in headings:
            self.tree.column(h, anchor=W,stretch=NO, width=100)
            self.tree.heading(h, text=h, anchor=W)
        hsb = ttk.Scrollbar(self, orient='horizontal')
        hsb.configure(command=self.tree.xview)
        self.tree.configure(xscrollcommand=hsb.set)
        hsb.pack(fill=X, side=BOTTOM)

        vsb = ttk.Scrollbar(self, orient='vertical')
        vsb.configure(command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(fill=Y, side=RIGHT)
        objs = session.query(self.table).all()
        for i in range(0, len(objs)):
            data = self.convert_to_list(objs[i])
            self.tree.insert('',index=i, iid=i, values=data)







# Calling pack method w.r.to vertical
# scrollbar


        self.tree.pack()

    def convert_to_list(self, obj):
        fields = self.table.get_fields()
        my_list = []
        for f in fields:
            val = getattr(obj, f)
            my_list.append(val)
        return my_list


class TableSelectUpdateFrame(Frame):

    def __init__(self, master=None, class_ref=None,
                 session: Session = None, font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue', cnf={}, **kw):
        super().__init__(master, cnf, **kw)
        self.session = session
        self.Table = class_ref
        self.table_dic = {}
        self.config(bg=bg)

        self.table_name = str(self.Table)
        self.table_name = self.table_name[self.table_name.rindex('.') + 1:self.table_name.rindex("'")]
        Label(self, text='Select/Update {} Form'.format(self.table_name), fg=fg,
              bg=bg, font=('Comic Sans MS', 12, 'bold')).pack()
        self.find_frame = Frame(self, bg=bg)
        self.find_frame.pack()
        pks = self.Table.get_primary_key()
        self.pk_dict = {}
        row = 0
        for pk in pks:
            self.pk_dict[pk] = StringVar()
            Label(self.find_frame, text=str(pk), fg=fg, bg=bg,
                  font=font, justify=LEFT).grid(
                row=row, column=0, stick='w', padx=5, pady=5)
            entry = Entry(self.find_frame, textvar=self.pk_dict[pk],
                          fg='black', bg='white',
                          font=('Comic Sans MS', 12,
                                'bold'))
            entry.grid(row=row, column=1, padx=5, pady=5)
            row += 1
        self.find_button = Button(self.find_frame,
                                  text='Retrieve {}'.format(self.table_name),
                                  command=self.retrieve_table,
                                  font=font,
                                  bg='black', fg=fg)
        self.find_button.grid(row=row + 1, column=0, padx=10, pady=5,
                              columnspan=2, sticky='ew')
        self.clear_button = Button(self.find_frame, text='clear fields',
                                   command=self.clear_fields, font=font,
                                   bg='black', fg=fg)
        self.clear_button.grid(row=row + 2, column=0, columnspan=2,
                               padx=10, pady=5, sticky='ew')
        self.find_frame.pack()
        self.inner_frame = Frame(self)
        self.inner_frame.pack()
        self.inner_frame.config(bg=bg)
        fields = self.Table.get_fields()
        for i in range(len(fields)):
            field = fields[i]
            if field not in pks:
                label = Label(self.inner_frame, text=field,
                              justify=LEFT, font=font, bg=bg, fg=fg)
                label.grid(row=i, column=0, padx=5, pady=5, sticky='w')
                self.table_dic[field] = StringVar()
                entry = Entry(self.inner_frame, textvar=self.table_dic[field],
                              font=font, bg='white', fg='black', state=NORMAL)
                entry.grid(row=i, column=1, padx=5)

        self.update_button = Button(self, text="Update",
                                    command=self.update_table,
                                    font=font, bg='black',
                                    fg=fg, width=40)
        self.update_button.pack()
        self.message_label = Label(self, text='', font=font, bg=bg,
                                   fg=fg)
        self.message_label.pack()

    def clear_fields(self):
        self.pk_var.set('')
        for k in self.table_dic:
            self.table_dic[k].set('')
        self.message_label.config(text='')

    def retrieve_table(self):
        try:
            pk_values = []
            for k in self.pk_dict:
                pk_values.append(self.pk_dict[k].get())
            pk_values = tuple(pk_values)
            obj = self.session.query(self.Table).get(pk_values)

            if obj is None:
                self.message_label.config(
                    text='No {} found with given ID'.format(self.table_name))
            else:
                self.message_label.config(text='{} found'.format(self.table_name))
                d = obj.to_dict()
                for k in d:
                    if k not in self.Table.get_primary_key():
                        if d[k] is not None:
                            self.table_dic[k].set(d[k])
        except Exception as ex:
            print('Problem encountered. {} not found, {}'.format(self.table_name, ex))
            self.message_label.config(text='Error encountered.  No {} returned'.format(self.table_name))

    def update_table(self):

        try:
            obj_dict = {}
            for k in self.table_dic:
                val = self.table_dic[k].get()
                if val != "":
                    obj_dict[k] = val
            pk_values = []
            for k in self.pk_dict:
                pk_values.append(self.pk_dict[k].get())
            pk_values = tuple(pk_values)
            table_obj = session.query(self.Table).get(pk_values)
            print(table_obj)

            for k in obj_dict:
                setattr(table_obj, k, obj_dict[k])
            session.commit()
            self.message_label.config(text='{} successfully updated'.format(self.table_name))

        except Exception as ex:
            print('Problem encountered. {} not updated'.format(self.table_name))
            print(ex)
            self.message_label.config(text='Error occurred. No {} updated'.format(self.table_name))
            session.rollback()


class TableSelectByPkFrame(Frame):

    def __init__(self, master=None, class_ref=None,
                 session: Session = None, font=('Comic Sans MS', 12, 'normal'),
                 fg: str = 'white', bg: str = 'blue', cnf={}, **kw):
        super().__init__(master, cnf, **kw)
        self.session = session
        self.Table = class_ref
        self.table_dic = {}
        self.config(bg=bg)

        self.table_name = str(self.Table)
        self.table_name = self.table_name[self.table_name.rindex('.') + 1:self.table_name.rindex("'")]
        Label(self, text='Select {}'.format(self.table_name), fg=fg,
              bg=bg, font=('Comic Sans MS', 12, 'bold')).pack()
        self.find_frame = Frame(self, bg=bg)
        self.find_frame.pack()
        pks = self.Table.get_primary_key()
        self.pk_dict = {}
        row = 0
        for pk in pks:
            self.pk_dict[pk] = StringVar()
            Label(self.find_frame, text=str(pk), fg=fg, bg=bg,
                  font=font, justify=LEFT).grid(
                row=row, column=0, stick='w', padx=5, pady=5)
            entry = Entry(self.find_frame, textvar=self.pk_dict[pk],
                          fg='black', bg='white',
                          font=('Comic Sans MS', 12,
                                'bold'))
            entry.grid(row=row, column=1, padx=5, pady=5)
            row += 1
        self.find_button = Button(self.find_frame,
                                  text='Retrieve {}'.format(self.table_name),
                                  command=self.retrieve_table,
                                  font=font,
                                  bg='black', fg=fg)
        self.find_button.grid(row=row + 1, column=0, padx=10, pady=5,
                              columnspan=2, sticky='ew')

        self.find_frame.pack()
        self.inner_frame = Frame(self)
        self.inner_frame.pack()
        self.inner_frame.config(bg=bg)
        fields = self.Table.get_fields()
        for i in range(len(fields)):
            field = fields[i]
            if field not in pks:
                label = Label(self.inner_frame, text=field,
                              justify=LEFT, font=font, bg=bg, fg=fg)
                label.grid(row=i, column=0, padx=5, pady=5, sticky='w')
                self.table_dic[field] = StringVar()
                entry = Entry(self.inner_frame, textvar=self.table_dic[field], state=DISABLED,
                              font=font, bg='white', fg='black')
                entry.grid(row=i, column=1, padx=5)
        self.message_label = Label(self, text='', font=font, bg=bg,
                                   fg=fg)
        self.message_label.pack()

    def retrieve_table(self):
        try:
            pk_values = []
            for k in self.pk_dict:
                pk_values.append(self.pk_dict[k].get())
            pk_values = tuple(pk_values)
            obj = self.session.query(self.Table).get(pk_values)

            if obj is None:
                self.message_label.config(
                    text='No {} found with given ID'.format(self.table_name))
            else:
                self.message_label.config(text='{} found'.format(self.table_name))
                d = obj.to_dict()
                for k in d:
                    if k not in self.Table.get_primary_key():
                        if d[k] is not None:
                            self.table_dic[k].set(d[k])
        except Exception as ex:
            print('Problem encountered. {} not found, {}'.format(self.table_name, ex))
            self.message_label.config(text='Error encountered.  No {} returned'.format(self.table_name))


def createframe(frame, table, session):
    global current_frame
    if current_frame is None:
        current_frame = frame(root, table, session)
        current_frame.pack()
    else:

        current_frame.pack_forget()
        current_frame.destroy()
        current_frame = frame(root, table, session)
        current_frame.pack()

def clear_frame():
    if current_frame is not None:
        for widgets in current_frame.winfo_children():
            widgets.destroy()
            current_frame.config(bg='White')






root = SampleApp()
session = Session(engine)
global current_frame
current_frame = None

root.mainloop()
